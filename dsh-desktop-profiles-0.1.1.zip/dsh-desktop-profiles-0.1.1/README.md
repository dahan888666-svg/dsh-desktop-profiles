# DSH Desktop Profiles（多 Profile 桌面增强）

给 DeepSeek Harness 桌面端加上 **Hermes 式的 Profile 切换**：侧边栏“新会话”上方多出一行 Profile，点 `＋` 新建、点名称切换；每个 Profile 拥有**独立的 DSH_HOME**，会话、账号凭据、插件、设置、附件完全隔离；切换在同一窗口完成，**不会中断其它 Profile 正在运行的任务**。

![侧边栏 Profile 行](docs/screenshot-row.png)

## 三种入口

| 场景 | 用什么 |
|---|---|
| 首次安装 | `Install.cmd`（会关闭应用一次，自动备份并打补丁） |
| **日常启动（推荐）** | `Launch.cmd`，或安装器创建的 **DeepSeek Harness (Profiles)** 快捷方式 |
| 检查 / 修复补丁 | `Repair.cmd` |

`Launch.cmd` 是**自愈启动器**：每次启动前检查 `resources/app.asar`，发现补丁被 DSH 更新覆盖时自动重打（补丁版本匹配时），再启动应用。

## 安装（Windows）

1. 双击 `Install.cmd`（自动探测安装目录；也可 `Install.cmd "D:\DSH"`）。
2. 提示“DeepSeek Harness 正在运行，是否关闭并继续” → 输入 `Y`。
3. 脚本会：只关闭**该安装目录**的进程 → 备份 `app.asar` 为 `app.asar.stock` → 替换为补丁版 → 把桌面/开始菜单里指向该程序的快捷方式改为指向 `Launch.cmd` → 启动应用。
4. 重启后侧边栏出现 Profile 行。

> 安装会关闭应用一次（进行中的任务会中断；会话数据不丢）。安装在 `Program Files` 下会自动请求管理员权限。

## 卸载 / 回滚

双击 `Uninstall.cmd`：恢复官方 `app.asar`，应用重启。**Profile 数据不会删除**，仍在 `%USERPROFILE%\.dsh\desktop-profiles`。

## 用法

| 操作 | 说明 |
|---|---|
| 切换 | 点侧边栏 Profile 行 → 选择另一个 Profile，当前窗口原地切换（过渡页约 1–4 秒） |
| 新建 | 点 `＋` → 填名称（小写字母/数字/短横线）、显示名 → 勾选“复制当前登录凭据”“沿用当前模型设置” → 创建并切换 |
| 删除 | 打开 Profile 列表，悬停非当前项点 `✕`，数据移入 `.trash`（可手工恢复） |
| 命令行 | `DeepSeek Harness.exe --profile work`；应用已在运行时执行同命令会**切换现有窗口** |
| 环境变量 | `DSH_DESKTOP_PROFILE=work` 作为默认启动 Profile |

## DSH 升级后会不会失效？

分三层保证，**应用和数据永远不会被弄坏**：

1. **数据层**：Profile 数据在用户目录（`%USERPROFILE%\.dsh\desktop-profiles`），官方升级不会触碰；插件、会话、凭据都安全。
2. **应用层**：补丁永远保留官方备份 `app.asar.stock`。补丁失败、版本不匹配、文件被占用时，启动器**不会强行打补丁**，应用按官方界面正常启动；随时可 `Uninstall.cmd` 回滚。
3. **功能层**：官方更新会用新的 `app.asar` 覆盖补丁。此时：
   - 通过安装器创建的快捷方式（`Launch.cmd`）启动 → 启动前自动检测并**重新打补丁**（补丁与当前 DSH 版本匹配时）；
   - 如果更新到了尚未适配的 DSH 版本 → 启动器保持官方界面并在 `%LOCALAPPDATA%\dsh-desktop-profiles\repair.log` 记录原因，安装匹配版本的 desktop-profiles 即可恢复；
   - 新版本的适配补丁放在 `payload-versions/<version>/`，无需改代码，只需随发布加一个目录。

**边界（如实说明）**：DSH 更新完成后由官方安装器直接重启应用的那一次，若你从官方快捷方式启动，可能先看到官方界面；关掉后用 `DeepSeek Harness (Profiles)` 快捷方式再开即恢复。要“升级后无需任何操作”，需要 DSH 官方支持 profile（上游能力），或固定 DSH 版本不升级。

> 建议：DSH 更新后，双击 `Repair.cmd` 一次，或直接用 Profiles 快捷方式启动。

## 隔离范围

每个非默认 Profile 使用独立目录 `<DSH_HOME>\desktop-profiles\<name>\home`：

| 数据 | 隔离 |
|---|---|
| 会话历史、定时任务 | ✅ 各 profile 独立 |
| 账号 / API 凭据（`.credentials.yaml`） | ✅ 独立（新建时默认复制一份，可关闭） |
| 插件、bundle、模型配置 | ✅ 独立 |
| UI 设置、附件、语音模型、运行缓存 | ✅ 独立 |
| Electron 缓存、更新记录 | ❌ 全局共享 |
| 平台网站 cookie（harness.deepseek.com） | ❌ 共享（DSH 账号凭据仍按 profile 隔离） |
| Web 前端 localStorage（草稿、面板固定等） | ❌ 按 origin 共享（后续版本处理） |

默认 Profile（`desktop`）**保持原目录与数据不变**，不做迁移。

## 任务不中断

每个已启动的 Profile 都有一个常驻 Host 子进程（约 +300 MB 私有内存/个）。切换只改变窗口指向的 Host，不会停止其它 Host：

- 在 A 里跑长任务 → 切到 B → A 的任务继续跑；
- 切回 A 时页面重新连回同一个 Host，进度和输出都在；
- 进程级验证：连续切换后两个 Host 的 PID 不变。

当前版本不会自动回收空闲 Host；不用时重启应用即可释放。

## 目录与文件

```
%USERPROFILE%\.dsh\
├─ sessions\ .credentials.yaml ...        # 默认 profile（原样）
├─ profiles\desktop\                      # 默认 profile 的插件配置（原样）
└─ desktop-profiles\                      # 新增
   ├─ registry.json                       # Profile 注册表 + 上次使用
   ├─ work\{meta.json, home\}
   └─ .trash\<时间>-<name>\
```

安装产物：

```
<安装目录>\resources\
├─ app.asar                               # 已打补丁
├─ app.asar.stock                         # 官方原版备份（卸载用）
├─ app.asar.previous                      # 上一次补丁版本
└─ dsh-profile-patch.json                 # 补丁清单（版本 / 哈希 / 文件列表）
```

## 发布到 GitHub

发布包结构（`tools/make-release.mjs` 自动生成）：

```
dsh-desktop-profiles-<version>\
├─ Install.cmd / Uninstall.cmd / Launch.cmd / Repair.cmd
├─ installer\           # deploy / revert / patch-check / asar / ps1 辅助
├─ payload\             # 当前版本补丁文件
├─ payload-versions\    # 未来版本补丁（可选，按 DSH 版本分目录）
├─ plugin\              # DSH bundle 载体（含安装器）
├─ docs\                # 截图
├─ README.md / LICENSE / CHANGELOG.md / VERSION
└─ GITHUB-RELEASE.md    # Release 页面正文
```

发布步骤：

```powershell
# 1) 适配新 DSH 版本时，只改 VERSION / CHANGELOG
# 2) 构建补丁树（需要官方 app.asar）
node tools\build.mjs
# 3) 组装 dist + 插件载体
node tools\make-dist.mjs
# 4) 生成 release 目录与 zip
node tools\make-release.mjs
# 5) 把 release\dsh-desktop-profiles-<version>.zip 作为 Release 资产上传
```

**适配新的 DSH 版本**：

1. 用 `tools/asar.mjs` 读取新版 `app.asar`，确认锚点函数仍存在（`resolveDesktopPaths`、Host 工厂、`newSessionRow`、`preload createProductApi`）；
2. 如有变化，更新 `src/blocks/*` 与 `tools/build.mjs` 的锚点，重新 `build`；
3. 把生成的 `build/app` 复制到 `dist-<新版本>/`，并在发布包中新增 `payload-versions/<dsh版本>/`；
4. 启动器会按当前 DSH 版本自动选用对应 payload。

## 开发与验证

- `src/profiles.js` — 注册表、目录布局、创建/删除
- `src/blocks/host-block.js` — 多 Host 并发与 active 绑定
- `src/blocks/switch-block.js` — 切换流程、IPC、第二实例
- `src/blocks/sidebar-profile-bar.js` — 侧边栏组件（注入共享 sidebar 包）
- `src/switch.html` — 过渡页
- `tools/asar.mjs` — asar 读写（无改动重打包与官方文件字节一致）
- `tools/build.mjs` / `apply.mjs` / `deploy.mjs` — 生成补丁 / 打补丁 / 部署
- `tools/make-dist.mjs` / `make-release.mjs` — 打包

验证记录见 [PLAN.md](PLAN.md) 第 12 节。
