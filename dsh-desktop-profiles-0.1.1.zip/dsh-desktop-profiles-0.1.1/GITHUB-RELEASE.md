# DSH Desktop Profiles 0.1.1

给 DeepSeek Harness 桌面端加多 Profile：独立会话/凭据、同窗口切换、切换不打断任务。

## 安装

1. 下载并解压本发布包。
2. 双击 `Install.cmd`（自动定位安装目录，也接受路径参数）。
3. 提示关闭应用时输入 `Y`，安装器备份 `app.asar`、打补丁并自动重启。
4. 重启后侧边栏“新会话”上方出现 Profile 行。

## 日常启动

请使用安装器创建的 **DeepSeek Harness (Profiles)** 快捷方式（或 `Launch.cmd`）。
它会在启动前检查补丁，DSH 更新覆盖后自动重打。

## 回滚

双击 `Uninstall.cmd`。Profile 数据保留在 `%USERPROFILE%\.dsh\desktop-profiles`。

## 支持版本

DSH Desktop 0.2.2-rc.3。其他版本安装器会拒绝（校验 `lib/main.js` 哈希），应用不受影响。
