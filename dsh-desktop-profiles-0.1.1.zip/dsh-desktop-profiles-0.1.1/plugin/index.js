import { existsSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

/**
 * Distribution carrier for the DSH Desktop Profiles enhancement.
 *
 * A DSH bundle runs inside the Host/Client, so it cannot rewrite the Electron
 * shell by itself. This plugin therefore reports whether the shell patch is
 * installed and points at the bundled one-click installer (`installer/Install.cmd`).
 * The installer performs the actual `app.asar` patch and requires one app restart.
 */
export const name = 'desktop-profiles'

export function apply(ctx) {
  const logger = ctx.logger?.('desktop-profiles')
  try {
    const installDir = dirname(process.execPath)
    const marker = join(installDir, 'resources', 'dsh-profile-patch.json')
    if (!existsSync(marker)) {
      logger?.info('shell patch not installed; run installer/Install.cmd inside this package (requires one restart)')
      return
    }
    const manifest = JSON.parse(readFileSync(marker, 'utf8'))
    logger?.info(`shell patch active for DSH ${manifest.desktopVersion}; profiles live in %USERPROFILE%\\.dsh\\desktop-profiles`)
  } catch (error) {
    logger?.warn(`could not inspect the desktop patch: ${String(error)}`)
  }
}
