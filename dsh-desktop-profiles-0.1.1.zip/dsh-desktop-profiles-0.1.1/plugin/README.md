# DSH Desktop Profiles

## 这是什么

给 DeepSeek Harness **桌面端**加上多 Profile：每个 Profile 独立 `DSH_HOME`（会话、账号凭据、插件、设置、附件隔离），侧边栏一行切换器，点 `＋` 新建并原地切换，切换不会中断其它 Profile 正在运行的任务。

## 为什么以“插件 + 安装器”分发

DSH 的 bundle 运行在 Host / Web Client 里，**改不了 Electron 外壳**（`resources/app.asar` 里的 `lib/main.js`）。所以本插件承担三件事：

1. 作为市场/团队分发的载体（可 `dsh plugin add` 或被插件市场收录）；
2. 随包携带一键安装器（`installer/`，含补丁文件与 asar 重打包工具）；
3. 启动时检测外壳补丁是否已安装，并在 Host 日志里给出提示。

真正的安装动作由 `installer/Install.cmd` 完成：关闭应用 → 备份并替换 `app.asar` → 重启生效。**必须重启一次**，这是 Electron 外壳的边界，无法绕过。

## 安装

```
plugin\installer\Install.cmd
```

或带安装目录：

```
plugin\installer\Install.cmd "D:\DSH"
```

卸载/回滚：`plugin\installer\Uninstall.cmd`。

## 支持的版本

补丁绑定 DSH Desktop **0.2.2-rc.3**（校验 `lib/main.js` 的 SHA-256）。其他版本会在安装前被拒绝，需重新构建补丁。

## 数据位置

- 默认 Profile：`%USERPROFILE%\.dsh`（原样，不迁移）
- 命名 Profile：`%USERPROFILE%\.dsh\desktop-profiles\<name>\home`
- 删除的 Profile：`%USERPROFILE%\.dsh\desktop-profiles\.trash\`

## 验证状态

- 侧边栏 Profile 行、创建、切换、切回、删除（回收站）均已在打包版副本上端到端验证；
- 切换前后两个 Profile 的 Host 进程 PID 不变（任务不中断）；
- `--profile` 直启与“第二实例切换现有窗口”已验证；
- 一键安装/卸载/回滚在副本上验证通过（安装器只关闭目标安装目录的进程）。
